# -*- coding: utf-8 -*-
# Opened from the add-on list: show the state and offer to apply or restore.
import xbmcgui

from resources.lib import patcher
from resources.lib.common import NAME, VSTREAM_DIR, BACKUP_DIR, log

messages = []


def collect(msg):
    log(msg)
    messages.append(msg)


choice = xbmcgui.Dialog().select(NAME, ['Appliquer les corrections', 'Restaurer vStream d\'origine'])
if choice == 0:
    patched, already, skipped = patcher.apply(VSTREAM_DIR, BACKUP_DIR, collect)
    summary = '%d fichier(s) corrigé(s), %d déjà corrigé(s), %d ignoré(s).' % (patched, already, skipped)
elif choice == 1:
    restored = patcher.restore(VSTREAM_DIR, BACKUP_DIR, collect)
    summary = '%d fichier(s) restauré(s).' % restored
    if restored:
        summary += '\nDésactivez l\'extension, sinon elle recorrigera vStream au prochain démarrage.'
else:
    summary = None

if summary:
    xbmcgui.Dialog().ok(NAME, '\n'.join(messages + [summary]))
