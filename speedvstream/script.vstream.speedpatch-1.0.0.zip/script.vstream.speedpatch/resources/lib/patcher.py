# -*- coding: utf-8 -*-
"""Applies (or removes) the startup speed fixes to an installed vStream.

Every patch is a list of exact text replacements. A file is only written when every
anchor of its patch is found, so an unexpected vStream version is left untouched.
"""
import os

MARKER = '# vstream-speedpatch'

DEFAULT_PATCH = [
    # home.py pulls trakt -> requests -> urllib3 (~6 s on a TV box) for every widget call.
    ('from resources.lib.home import cHome\n',
     MARKER + ': cHome / cSearch importes a la demande\n'),
    ('from resources.lib.search import cSearch\n', ''),
    ("    if sSiteName == 'cHome':\n        oHome = cHome()",
     "    if sSiteName == 'cHome':\n        from resources.lib.home import cHome\n        oHome = cHome()"),
    ("    if sSiteName == 'globalSearch':\n        oSearch = cSearch()",
     "    if sSiteName == 'globalSearch':\n        from resources.lib.search import cSearch\n        oSearch = cSearch()"),
]

EVAL_PASTE = '''

''' + MARKER + ''': eval() d'un paste de plusieurs Mo prend plusieurs secondes sur une box TV,
# et chaque widget le refait. On garde une copie marshal (7x plus rapide a relire), indexee par
# un CRC du contenu : si le paste change, la copie est refaite. Stockage interne de Kodi de
# preference (Android : bien plus rapide que /sdcard), sinon a cote du cache.
import marshal as _sp_marshal
import os as _sp_os
import zlib as _sp_zlib


def _parsedDir():
    internal = _sp_os.path.dirname(_sp_os.path.dirname(xbmcvfs.translatePath('special://xbmcbin')))
    for base in (internal, _sp_os.path.dirname(REALCACHE)):
        folder = _sp_os.path.join(base, 'vstream_pastebin_parsed')
        try:
            if not _sp_os.path.isdir(folder):
                _sp_os.makedirs(folder)
            if _sp_os.access(folder, _sp_os.W_OK):
                return folder
        except Exception:
            pass
    return _sp_os.path.join(_sp_os.path.dirname(REALCACHE), 'vstream_pastebin_parsed')


PARSED_DIR = _parsedDir()
_parsed = {}  # un meme appel relit souvent plusieurs fois les memes pastes


def evalPaste(pasteID, sContent):
    path = _sp_os.path.join(PARSED_DIR, '%s_%08x.bin' % (pasteID, _sp_zlib.crc32(sContent.encode('utf-8')) & 0xffffffff))
    if path in _parsed:
        return _parsed[path]
    try:
        with open(path, 'rb') as f:
            lines = _sp_marshal.load(f)
        _parsed[path] = lines
        return lines
    except Exception:
        pass

    lines = eval(sContent)
    _parsed[path] = lines
    try:
        for old in _sp_os.listdir(PARSED_DIR):
            if old.startswith(pasteID + '_'):
                _sp_os.remove(_sp_os.path.join(PARSED_DIR, old))
        tmp = '%s.%d.tmp' % (path, threading.get_ident())
        with open(tmp, 'wb') as f:
            _sp_marshal.dump(lines, f)
        _sp_os.replace(tmp, path)
    except Exception as e:
        VSlog('Pastebin - parsed cache error, ID=%s, e=%s' % (pasteID, e))
    return lines
'''

PASTEBIN_PATCH = [
    ('lock = threading.Semaphore()\n', 'lock = threading.Semaphore()\n' + EVAL_PASTE),
    ('                lines = eval(sContent)       # TODO trop long\n',
     '                lines = evalPaste(pasteBin, sContent)\n'),
    ('            lines = eval(sContent)       # TODO trop long\n',
     '            lines = evalPaste(pasteBin, sContent)\n'),
]

TARGETS = [
    ('default.py', DEFAULT_PATCH),
    (os.path.join('resources', 'sites', 'pastebin.py'), PASTEBIN_PATCH),
]


def _read(path):
    with open(path, 'rb') as f:
        raw = f.read().decode('utf-8')
    crlf = '\r\n' in raw
    return raw.replace('\r\n', '\n'), crlf


def _write(path, text, crlf):
    if crlf:
        text = text.replace('\n', '\r\n')
    tmp = path + '.speedpatch.tmp'
    with open(tmp, 'wb') as f:
        f.write(text.encode('utf-8'))
    os.replace(tmp, path)


def is_patched(text):
    return MARKER in text


def patch_text(text, patch):
    """Return the patched text, or None if an anchor is missing (unknown vStream version)."""
    for old, new in patch:
        if text.count(old) != 1:
            return None
        text = text.replace(old, new)
    return text


def apply(vstream_dir, backup_dir, log):
    """Patch every target file. Returns (patched, already, skipped) file counts."""
    patched = already = skipped = 0
    for rel, patch in TARGETS:
        path = os.path.join(vstream_dir, rel)
        if not os.path.isfile(path):
            log('introuvable : %s' % rel)
            skipped += 1
            continue
        text, crlf = _read(path)
        if is_patched(text):
            already += 1
            continue
        new = patch_text(text, patch)
        if new is None:
            log('version de vStream inattendue, fichier laisse intact : %s' % rel)
            skipped += 1
            continue
        backup = os.path.join(backup_dir, rel.replace(os.sep, '_') + '.orig')
        if not os.path.isdir(backup_dir):
            os.makedirs(backup_dir)
        with open(path, 'rb') as src, open(backup, 'wb') as dst:
            dst.write(src.read())
        _write(path, new, crlf)
        log('corrige : %s' % rel)
        patched += 1
    return patched, already, skipped


def restore(vstream_dir, backup_dir, log):
    """Put back the original files saved by apply(). Returns the number restored."""
    restored = 0
    for rel, _ in TARGETS:
        path = os.path.join(vstream_dir, rel)
        backup = os.path.join(backup_dir, rel.replace(os.sep, '_') + '.orig')
        if not (os.path.isfile(path) and os.path.isfile(backup)):
            continue
        text, _ = _read(path)
        if not is_patched(text):
            continue  # vStream was updated since: the backup is stale, leave the new file alone
        with open(backup, 'rb') as src:
            data = src.read()
        tmp = path + '.speedpatch.tmp'
        with open(tmp, 'wb') as dst:
            dst.write(data)
        os.replace(tmp, path)
        log('restaure : %s' % rel)
        restored += 1
    return restored
