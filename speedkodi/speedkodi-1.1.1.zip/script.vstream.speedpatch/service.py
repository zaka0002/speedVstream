# -*- coding: utf-8 -*-
# Patches vStream at startup, then re-checks every 10 minutes in case it was updated meanwhile.
import xbmc
import xbmcgui

from resources.lib import patcher
from resources.lib.common import NAME, ADDONS_DIR, BACKUP_DIR, log

CHECK_EVERY = 600  # seconds


def check(notify):
    try:
        patched, _, _ = patcher.apply(ADDONS_DIR, BACKUP_DIR, log)
    except Exception as e:
        log('erreur : %s' % e)
        return
    if patched and notify:
        xbmcgui.Dialog().notification(NAME, 'vStream / alkoFlix accélérés', xbmcgui.NOTIFICATION_INFO, 3000)


monitor = xbmc.Monitor()
check(notify=False)  # silent at boot: the widgets are loading
while not monitor.waitForAbort(CHECK_EVERY):
    check(notify=True)
