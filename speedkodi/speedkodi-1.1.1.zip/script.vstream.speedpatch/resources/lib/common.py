# -*- coding: utf-8 -*-
import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
NAME = ADDON.getAddonInfo('name')
ADDONS_DIR = xbmcvfs.translatePath('special://home/addons/')
BACKUP_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo('profile') + 'originals/')


def log(msg):
    xbmc.log('[%s] %s' % (NAME, msg), xbmc.LOGINFO)
