# -*- coding: utf-8 -*-
"""Applies (or removes) startup speed fixes to installed vStream and alkoFlix.

Each target file has a transform that returns the patched text, or None when the file
does not look like the expected version: such a file is left untouched.
"""
import os

MARKER = '# vstream-speedpatch'


# --------------------------------------------------------------------------- helpers

def replacements(patch):
    """Transform built from exact text replacements; every anchor must occur exactly once."""
    def transform(text):
        for old, new in patch:
            if text.count(old) != 1:
                return None
            text = text.replace(old, new)
        return text
    return transform


# --------------------------------------------------------------------------- vStream

VSTREAM_DEFAULT = replacements([
    # home.py pulls trakt -> requests -> urllib3 (~6 s on a TV box) for every widget call.
    ('from resources.lib.home import cHome\n',
     MARKER + ': cHome / cSearch importes a la demande\n'),
    ('from resources.lib.search import cSearch\n', ''),
    ("    if sSiteName == 'cHome':\n        oHome = cHome()",
     "    if sSiteName == 'cHome':\n        from resources.lib.home import cHome\n        oHome = cHome()"),
    ("    if sSiteName == 'globalSearch':\n        oSearch = cSearch()",
     "    if sSiteName == 'globalSearch':\n        from resources.lib.search import cSearch\n        oSearch = cSearch()"),
])

EVAL_PASTE = '''

''' + MARKER + ''': eval() d'un paste de plusieurs Mo prend plusieurs secondes sur une box TV,
# et chaque widget le refait. On garde une copie marshal (7x plus rapide a relire), indexee par
# un CRC du contenu : si le paste change, la copie est refaite. Stockage interne de Kodi de
# preference (Android : bien plus rapide que /sdcard), sinon a cote du cache.
import marshal as _sp_marshal
import os as _sp_os
import zlib as _sp_zlib


def _parsedDir():
    internal = _sp_os.path.dirname(_sp_os.path.dirname(xbmcvfs.translatePath('special://xbmcbin')))
    for base in (internal, _sp_os.path.dirname(REALCACHE)):
        folder = _sp_os.path.join(base, 'vstream_pastebin_parsed')
        try:
            if not _sp_os.path.isdir(folder):
                _sp_os.makedirs(folder)
            if _sp_os.access(folder, _sp_os.W_OK):
                return folder
        except Exception:
            pass
    return _sp_os.path.join(_sp_os.path.dirname(REALCACHE), 'vstream_pastebin_parsed')


PARSED_DIR = _parsedDir()
_parsed = {}  # un meme appel relit souvent plusieurs fois les memes pastes


def evalPaste(pasteID, sContent):
    path = _sp_os.path.join(PARSED_DIR, '%s_%08x.bin' % (pasteID, _sp_zlib.crc32(sContent.encode('utf-8')) & 0xffffffff))
    if path in _parsed:
        return _parsed[path]
    try:
        with open(path, 'rb') as f:
            lines = _sp_marshal.load(f)
        _parsed[path] = lines
        return lines
    except Exception:
        pass

    lines = eval(sContent)
    _parsed[path] = lines
    try:
        for old in _sp_os.listdir(PARSED_DIR):
            if old.startswith(pasteID + '_'):
                _sp_os.remove(_sp_os.path.join(PARSED_DIR, old))
        tmp = '%s.%d.tmp' % (path, threading.get_ident())
        with open(tmp, 'wb') as f:
            _sp_marshal.dump(lines, f)
        _sp_os.replace(tmp, path)
    except Exception as e:
        VSlog('Pastebin - parsed cache error, ID=%s, e=%s' % (pasteID, e))
    return lines
'''

VSTREAM_PASTEBIN = replacements([
    ('lock = threading.Semaphore()\n', 'lock = threading.Semaphore()\n' + EVAL_PASTE),
    ('                lines = eval(sContent)       # TODO trop long\n',
     '                lines = evalPaste(pasteBin, sContent)\n'),
    ('            lines = eval(sContent)       # TODO trop long\n',
     '            lines = evalPaste(pasteBin, sContent)\n'),
])


# --------------------------------------------------------------------------- alkoFlix

ALKO_LAZY_MODULE = MARKER + '''
# -*- coding: utf-8 -*-
# Chargement paresseux de requests : l'importer coute 3 a 4 s par widget sur une box TV,
# alors qu'un widget servi depuis le cache ne fait aucun appel reseau.
import threading


class _LazyRequests(object):
    """Se comporte comme le module requests, importe au premier attribut demande."""
    def __getattr__(self, name):
        import requests as real
        return getattr(real, name)


requests = _LazyRequests()


class LazySession(object):
    """Session requests creee (avec ses adaptateurs) a sa premiere utilisation."""
    def __init__(self, factory):
        object.__setattr__(self, '_sp_factory', factory)
        object.__setattr__(self, '_sp_session', None)
        object.__setattr__(self, '_sp_lock', threading.Lock())

    def _sp_get(self):
        session = object.__getattribute__(self, '_sp_session')
        if session is None:
            with object.__getattribute__(self, '_sp_lock'):
                session = object.__getattribute__(self, '_sp_session')
                if session is None:
                    session = object.__getattribute__(self, '_sp_factory')()
                    object.__setattr__(self, '_sp_session', session)
        return session

    def __getattr__(self, name):
        return getattr(self._sp_get(), name)

    def __setattr__(self, name, value):
        setattr(self._sp_get(), name, value)
'''

ALKO_LAZY_IMPORT = 'from modules.speedpatch_lazy import requests, LazySession  ' + MARKER


def alko_lazy_requests(text):
    """`import requests` -> lazy proxy; module-level `session = requests.Session()` block
    (with its Retry / mount lines) -> session built on first use."""
    lines = text.split('\n')
    if lines.count('import requests') != 1:
        return None
    lines[lines.index('import requests')] = ALKO_LAZY_IMPORT

    if lines.count('session = requests.Session()') == 1:
        start = lines.index('session = requests.Session()')
        end = start
        for i in range(start + 1, min(start + 40, len(lines))):
            if lines[i].startswith(('def ', 'class ', '@')):
                break
            if lines[i].startswith('session.'):
                end = i
        block = lines[start:end + 1]
        wrapped = ['def _speedpatch_session():']
        wrapped += [('\t' + l) if l.strip() else l for l in block]
        wrapped += ['\treturn session', 'session = LazySession(_speedpatch_session)']
        lines[start:end + 1] = wrapped
    return '\n'.join(lines)


ALKO_WATCHLIST = replacements([
    ('def local_watchlist_contains(media_type, tmdb_id):\n'
     '\ttry: return str(tmdb_id) in get_local_watchlist_ids(media_type)\n',
     MARKER + ': un widget de 20 films ouvrait 20 fois la base pour la meme liste.\n'
     '_sp_watchlist_memo = {}\n\n'
     'def local_watchlist_contains(media_type, tmdb_id):\n'
     '\timport time as _sp_time\n'
     '\tcached = _sp_watchlist_memo.get(media_type)\n'
     '\tif not cached or _sp_time.time() - cached[0] > 10:\n'
     '\t\tcached = (_sp_time.time(), get_local_watchlist_ids(media_type))\n'
     '\t\t_sp_watchlist_memo[media_type] = cached\n'
     '\ttry: return str(tmdb_id) in cached[1]\n'),
])

ALKO_LIB = os.path.join('resources', 'lib')
ALKO_LAZY_FILE = os.path.join(ALKO_LIB, 'modules', 'speedpatch_lazy.py')


def alko_targets(addon_dir):
    """Every module with a top-level `import requests` (19 in 2.3.14, found by scanning so
    new versions are covered), plus the watchlist lookup."""
    targets = []
    lib = os.path.join(addon_dir, ALKO_LIB)
    for folder, dirs, files in os.walk(lib):
        dirs[:] = [d for d in dirs if d != '__pycache__']
        for name in files:
            if not name.endswith('.py'):
                continue
            path = os.path.join(folder, name)
            rel = os.path.relpath(path, addon_dir)
            if rel == ALKO_LAZY_FILE:
                continue
            try:
                text = _read(path)[0]
            except Exception:
                continue
            if 'import requests' in text.split('\n') or ALKO_LAZY_IMPORT in text:
                targets.append((rel, alko_lazy_requests))
    targets.sort()
    targets.append((os.path.join(ALKO_LIB, 'caches', 'watched_cache.py'), ALKO_WATCHLIST))
    return targets

# --------------------------------------------------------------------------- registry

# addon id -> (files to patch, or a function of the add-on folder returning them; files to create)
ADDONS = {
    'plugin.video.vstream': (
        [('default.py', VSTREAM_DEFAULT),
         (os.path.join('resources', 'sites', 'pastebin.py'), VSTREAM_PASTEBIN)],
        {},
    ),
    'plugin.video.alkoflix': (
        alko_targets,
        {ALKO_LAZY_FILE: ALKO_LAZY_MODULE},
    ),
}


def _targets(spec, addon_dir):
    return spec(addon_dir) if callable(spec) else spec


# --------------------------------------------------------------------------- file io

def _read(path):
    with open(path, 'rb') as f:
        raw = f.read().decode('utf-8')
    return raw.replace('\r\n', '\n'), '\r\n' in raw


def _write(path, text, crlf=False):
    if crlf:
        text = text.replace('\n', '\r\n')
    tmp = path + '.speedpatch.tmp'
    with open(tmp, 'wb') as f:
        f.write(text.encode('utf-8'))
    os.replace(tmp, path)


def is_patched(text):
    return MARKER in text


def _backup_path(backup_dir, addon_id, rel):
    return os.path.join(backup_dir, addon_id, rel.replace(os.sep, '_') + '.orig')


# --------------------------------------------------------------------------- api

def apply(addons_dir, backup_dir, log):
    """Patch every installed target add-on. Returns (patched, already, skipped) file counts."""
    patched = already = skipped = 0
    for addon_id, (targets, created) in ADDONS.items():
        addon_dir = os.path.join(addons_dir, addon_id)
        if not os.path.isdir(addon_dir):
            continue
        # Patch every file first (in memory) so a partly unexpected version is left whole.
        pending = []
        for rel, transform in _targets(targets, addon_dir):
            path = os.path.join(addon_dir, rel)
            if not os.path.isfile(path):
                log('%s : introuvable : %s' % (addon_id, rel))
                skipped += 1
                continue
            text, crlf = _read(path)
            if is_patched(text):
                already += 1
                continue
            new = transform(text)
            if new is None:
                log('%s : version inattendue, fichier laisse intact : %s' % (addon_id, rel))
                skipped += 1
                continue
            pending.append((rel, path, new, crlf))

        if pending:
            for rel, content in created.items():
                path = os.path.join(addon_dir, rel)
                if not os.path.isfile(path) or not is_patched(_read(path)[0]):
                    _write(path, content)
        for rel, path, new, crlf in pending:
            backup = _backup_path(backup_dir, addon_id, rel)
            if not os.path.isdir(os.path.dirname(backup)):
                os.makedirs(os.path.dirname(backup))
            with open(path, 'rb') as src, open(backup, 'wb') as dst:
                dst.write(src.read())
            _write(path, new, crlf)
            log('%s : corrige : %s' % (addon_id, rel))
            patched += 1
    return patched, already, skipped


def restore(addons_dir, backup_dir, log):
    """Put back the original files saved by apply(). Returns the number restored."""
    restored = 0
    for addon_id, (targets, created) in ADDONS.items():
        addon_dir = os.path.join(addons_dir, addon_id)
        if not os.path.isdir(addon_dir):
            continue
        for rel, _ in _targets(targets, addon_dir):
            path = os.path.join(addon_dir, rel)
            backup = _backup_path(backup_dir, addon_id, rel)
            legacy = os.path.join(backup_dir, rel.replace(os.sep, '_') + '.orig')  # v1.0 layout
            if not os.path.isfile(backup) and os.path.isfile(legacy):
                backup = legacy
            if not (os.path.isfile(path) and os.path.isfile(backup)):
                continue
            if not is_patched(_read(path)[0]):
                continue  # updated since: the backup is stale, leave the new file alone
            with open(backup, 'rb') as src:
                data = src.read()
            tmp = path + '.speedpatch.tmp'
            with open(tmp, 'wb') as dst:
                dst.write(data)
            os.replace(tmp, path)
            log('%s : restaure : %s' % (addon_id, rel))
            restored += 1
        for rel in created:
            path = os.path.join(addon_dir, rel)
            if os.path.isfile(path) and is_patched(_read(path)[0]):
                os.remove(path)
    return restored
